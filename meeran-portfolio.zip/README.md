# Meeran Ahmed R. — Portfolio

A responsive, single-page portfolio for Meeran’s freelance web development and creative work. It is built with plain HTML, CSS, and JavaScript; no package install or build step is required.

## Run locally

Serve this folder with any static web server. For example:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Included

- Light and dark themes, responsive navigation, project filters, and scroll progress
- A centered capsule-style desktop nav with a compact mobile menu
- A stationary wireframe globe surrounded by three independently animated skill orbits
- Résumé and portfolio skills in the orbits: web technologies, programming languages, databases, developer tools, creative software and practice, text-only AI tool names, and English, Hindi, Urdu, and Tamil
- A forest-green, rose, and lime palette drawn from the rest of Meeran’s portfolio
- Freelance-first projects and Experience, with the Pathfinder Implementation Executive role shown only in Experience
- Meeran’s supplied portrait crop, excluding the visible corner mark
- Education, certifications, awards, contact links, scroll reveals, ticker, counters, and hover details
- Reduced-motion support; no animation library or external font dependency
- Résumé download at `assets/Meeran-Ahmed-R-Resume.pdf`

## Design & motion references

The page is original and tailored to Meeran. Its clean hierarchy and interactive details take broad inspiration from [Paweł Szostak’s portfolio](https://www.pszostak.pl/); its motion-led presentation takes cues from [Vyonex](https://www.vyonex.co.in/). The Skills visualization and capsule navigation are adapted for Meeran’s own skills and content, not copied verbatim.
